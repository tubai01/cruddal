﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Gallery.Models
{
    public class Galleries
    {
        public long ImageId { get; set; }
        public string ImageName { get; set; }
        public HttpPostedFileBase src { get; set; }
    }
}