﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Gallery.Models;
using System.Web.Script.Serialization;
using System.IO;
using System.Drawing;
using System.Text;
using System.Reflection;
namespace Gallery.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {

            ViewBag.Message = "Gallery";
            DirectoryInfo dirInfo = new DirectoryInfo(System.Web.HttpContext.Current.Server.MapPath("~/Videos"));
            List<FileInfo> files = dirInfo.GetFiles().ToList();

            //pass the data trough the "View" method
            return View(files);
        }

        public ActionResult About()
        {
            return View();

           
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        List<Galleries> CurrentGalleries = new List<Galleries>();
        [HttpPost]
        public JsonResult GetImages(Galleries model)
        {
            
            if (TempData["Galleries"] == null)
            {
                foreach (string file in Request.Files)
                {
                   
                    model.src = Request.Files[file];
                    model.ImageName = model.src.FileName;
                }
                CurrentGalleries.Add(model);
            }
            else
            {
                
                CurrentGalleries = ((List<Galleries>)TempData["Galleries"]);
                foreach (string file in Request.Files)
                {

                    model.src = Request.Files[file];
                    model.ImageName = model.src.FileName;
                }
                CurrentGalleries.Add(model);
            }

            TempData["Galleries"] = CurrentGalleries;


            var jsonSerialiser = new JavaScriptSerializer();
            //var json = jsonSerialiser.Serialize(CurrentGalleries);

            return Json(false);

        }
        [HttpPost]
        public JsonResult DelImages(Galleries model)
        {
           
            if (TempData["Galleries"] != null)
            {
                CurrentGalleries = ((List<Galleries>)TempData["Galleries"]);
                for (int i = 0; i < CurrentGalleries.Count(); i++)
                {
                    if (CurrentGalleries[i].ImageName.Contains(model.ImageName))
                    {
                        CurrentGalleries.RemoveAt(i);
                    }
                }
            }


            TempData["Galleries"] = CurrentGalleries;
            var jsonSerialiser = new JavaScriptSerializer();
           // var json = jsonSerialiser.Serialize(CurrentGalleries);

            return Json(false);
        }

        public JsonResult SaveImages()
        {
          //  byte[] imageBytes = null;
            //MemoryStream ms = null;
            foreach (Galleries file in ((List<Galleries>)TempData["Galleries"]))
            {
                var _file = file.src;
                var uploadFilesDir = System.Web.HttpContext.Current.Server.MapPath("~/Videos");
                if (!Directory.Exists(uploadFilesDir))
                {
                    Directory.CreateDirectory(uploadFilesDir);
                }
                var fileSavePath = Path.Combine(uploadFilesDir, file.ImageName);

                // Save the uploaded file to "UploadedFiles" folder
                file.src.SaveAs(fileSavePath);



            
            }
            TempData["Galleries"] = null;
            
            return Json(false);
        }
      
    }
}